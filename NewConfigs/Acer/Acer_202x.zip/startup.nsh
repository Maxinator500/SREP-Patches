@echo -off
cls

for %i run (0 5)
  fs%i:
  if exist "SmokelessRuntimeEFIPatcher(019).efi" then
    SmokelessRuntimeEFIPatcher(019).efi ENG
  endif
endfor